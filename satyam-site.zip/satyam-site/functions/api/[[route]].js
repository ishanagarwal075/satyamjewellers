// Cloudflare Pages Function: backend for the Satyam Jewellers catalogue.
// Needs one KV binding named STORE and these secrets: OWNER_ID, OWNER_PASSWORD
// (optional: SESSION_SECRET). Everything lives under /api/*.

const enc = new TextEncoder();
const SESSION_HOURS = 12;
const MAX_FAILS = 8;          // wrong logins allowed per IP...
const FAIL_WINDOW = 900;      // ...within 15 minutes
const MAX_IMAGE_BYTES = 1_500_000;
const MAX_CATALOG_BYTES = 2_000_000;

const json = (data, status = 200, extra = {}) =>
  new Response(JSON.stringify(data), {
    status,
    headers: { "Content-Type": "application/json", "Cache-Control": "no-store", ...extra },
  });

function b64url(bytes) {
  let s = "";
  for (const b of bytes) s += String.fromCharCode(b);
  return btoa(s).replace(/\+/g, "-").replace(/\//g, "_").replace(/=+$/, "");
}

async function hmac(secret, msg) {
  const key = await crypto.subtle.importKey("raw", enc.encode(secret), { name: "HMAC", hash: "SHA-256" }, false, ["sign"]);
  return b64url(new Uint8Array(await crypto.subtle.sign("HMAC", key, enc.encode(msg))));
}

// Compare two strings without leaking where they differ.
async function safeEqual(a, b) {
  const [x, y] = await Promise.all([hmac("cmp", String(a)), hmac("cmp", String(b))]);
  let r = 0;
  for (let i = 0; i < x.length; i++) r |= x.charCodeAt(i) ^ y.charCodeAt(i);
  return r === 0;
}

async function pbkdf2(password, salt) {
  const key = await crypto.subtle.importKey("raw", enc.encode(password), "PBKDF2", false, ["deriveBits"]);
  const bits = await crypto.subtle.deriveBits(
    { name: "PBKDF2", salt: enc.encode(salt), iterations: 100000, hash: "SHA-256" },
    key,
    256
  );
  return b64url(new Uint8Array(bits));
}

async function checkCredentials(env, id, password) {
  const rec = await env.STORE.get("auth", "json");
  if (rec) {
    const hash = await pbkdf2(password, rec.salt);
    const idOk = await safeEqual(id.toLowerCase(), rec.id.toLowerCase());
    const pwOk = await safeEqual(hash, rec.hash);
    return idOk && pwOk;
  }
  if (!env.OWNER_ID || !env.OWNER_PASSWORD) return false;
  const idOk = await safeEqual(id.toLowerCase(), env.OWNER_ID.toLowerCase());
  const pwOk = await safeEqual(password, env.OWNER_PASSWORD);
  return idOk && pwOk;
}

// Token secret changes whenever the password changes, so old tokens stop working.
async function tokenSecret(env) {
  const rec = await env.STORE.get("auth", "json");
  const base = rec ? rec.hash : env.OWNER_PASSWORD;
  if (!base) return null;
  return (env.SESSION_SECRET || "") + "|" + base;
}

async function makeToken(env) {
  const secret = await tokenSecret(env);
  const exp = Date.now() + SESSION_HOURS * 3600 * 1000;
  return { token: exp + "." + (await hmac(secret, "owner:" + exp)), expires: exp };
}

async function isAuthed(request, env) {
  const h = request.headers.get("Authorization") || "";
  const token = h.startsWith("Bearer ") ? h.slice(7) : "";
  const [exp, sig] = token.split(".");
  if (!exp || !sig || !(Number(exp) > Date.now())) return false;
  const secret = await tokenSecret(env);
  if (!secret) return false;
  return safeEqual(sig, await hmac(secret, "owner:" + exp));
}

async function readJson(request) {
  try { return await request.json(); } catch (e) { return null; }
}

export async function onRequest(context) {
  const { request, env } = context;
  if (!env.STORE) return json({ error: "KV binding 'STORE' is missing." }, 500);

  const url = new URL(request.url);
  const path = url.pathname.replace(/\/+$/, "");
  const method = request.method;

  // ---------- PUBLIC: catalogue ----------
  if (path === "/api/catalog" && method === "GET") {
    const raw = await env.STORE.get("catalog");
    return new Response(raw || "null", {
      headers: { "Content-Type": "application/json", "Cache-Control": "no-cache" },
    });
  }

  // ---------- PUBLIC: product images ----------
  if (path.startsWith("/api/img/") && method === "GET") {
    const id = path.slice("/api/img/".length);
    if (!/^[a-f0-9-]{36}$/.test(id)) return new Response("Not found", { status: 404 });
    const { value, metadata } = await env.STORE.getWithMetadata("img:" + id, "arrayBuffer");
    if (!value) return new Response("Not found", { status: 404 });
    return new Response(value, {
      headers: {
        "Content-Type": (metadata && metadata.type) || "image/jpeg",
        "Cache-Control": "public, max-age=31536000, immutable",
      },
    });
  }

  // ---------- LOGIN ----------
  if (path === "/api/login" && method === "POST") {
    const ip = request.headers.get("CF-Connecting-IP") || "unknown";
    const failKey = "fail:" + ip;
    const fails = parseInt((await env.STORE.get(failKey)) || "0", 10);
    if (fails >= MAX_FAILS) return json({ error: "Too many wrong attempts. Try again in 15 minutes." }, 429);

    const body = await readJson(request);
    if (!body || typeof body.id !== "string" || typeof body.password !== "string") return json({ error: "Bad request" }, 400);

    if (!(await checkCredentials(env, body.id.trim(), body.password))) {
      await env.STORE.put(failKey, String(fails + 1), { expirationTtl: FAIL_WINDOW });
      return json({ error: "Wrong Login ID or password." }, 401);
    }
    if (fails) await env.STORE.delete(failKey);
    return json(await makeToken(env));
  }

  // ---------- EVERYTHING BELOW NEEDS OWNER LOGIN ----------
  if (!(await isAuthed(request, env))) return json({ error: "Not logged in" }, 401);

  if (path === "/api/catalog" && method === "PUT") {
    const text = await request.text();
    if (text.length > MAX_CATALOG_BYTES) return json({ error: "Catalogue too large" }, 413);
    let data;
    try { data = JSON.parse(text); } catch (e) { return json({ error: "Bad JSON" }, 400); }
    if (!data || typeof data.store !== "object" || !Array.isArray(data.categories) || !Array.isArray(data.products)) {
      return json({ error: "Invalid catalogue" }, 400);
    }
    // Never store inline photos in the catalogue; they must be uploaded via /api/image.
    if (data.products.some(p => typeof p.image === "string" && p.image.startsWith("data:"))) {
      return json({ error: "Photos must be uploaded first" }, 400);
    }
    await env.STORE.put("catalog", JSON.stringify({ store: data.store, categories: data.categories, products: data.products }));
    return json({ ok: true });
  }

  if (path === "/api/image" && method === "POST") {
    const type = (request.headers.get("Content-Type") || "").split(";")[0].trim();
    if (!["image/jpeg", "image/png", "image/webp"].includes(type)) return json({ error: "Only JPG, PNG or WebP photos" }, 415);
    const buf = await request.arrayBuffer();
    if (buf.byteLength === 0 || buf.byteLength > MAX_IMAGE_BYTES) return json({ error: "Photo too large (max 1.5 MB)" }, 413);
    const id = crypto.randomUUID();
    await env.STORE.put("img:" + id, buf, { metadata: { type } });
    return json({ url: "/api/img/" + id });
  }

  if (path === "/api/change-login" && method === "POST") {
    const body = await readJson(request);
    if (!body || typeof body.current !== "string" || typeof body.id !== "string" || typeof body.password !== "string") {
      return json({ error: "Bad request" }, 400);
    }
    const rec = await env.STORE.get("auth", "json");
    const currentId = rec ? rec.id : env.OWNER_ID || "";
    if (!(await checkCredentials(env, currentId, body.current))) return json({ error: "Current password is incorrect." }, 401);

    const id = body.id.trim();
    if (id.length < 3 || body.password.length < 6) return json({ error: "ID needs 3+ characters, password 6+." }, 400);

    const salt = crypto.randomUUID();
    await env.STORE.put("auth", JSON.stringify({ id, salt, hash: await pbkdf2(body.password, salt) }));
    return json(await makeToken(env)); // fresh token, since the old one is now invalid
  }

  return json({ error: "Not found" }, 404);
}
