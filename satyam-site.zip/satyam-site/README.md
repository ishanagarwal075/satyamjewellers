# Satyam Jewellers – Go-Live Guide (Cloudflare, free)

Folder layout (keep exactly like this):

```
public/index.html            <- the website
functions/api/[[route]].js   <- the backend (saves products, photos, owner login)
```

## One-time setup (about 15 minutes, no coding)

### 1. Put the files on GitHub
1. Create a free account at github.com and click **New repository** (name it e.g. `satyam-site`, keep it Private).
2. Click **uploading an existing file** and drag in the `public` and `functions` folders from this zip (the folders, not just the files inside).
3. Click **Commit changes**.

### 2. Create the Cloudflare site
1. Create a free account at dash.cloudflare.com.
2. **Workers & Pages → Create → Pages → Connect to Git** and choose your repository.
3. Build settings: **Framework preset: None**, **Build command: (leave empty)**, **Build output directory: `public`**.
4. Click **Save and Deploy**. (The first deploy will not save anything yet, that is fine.)

### 3. Create the storage (this is where products and photos live)
1. **Storage & Databases → KV → Create** a namespace named `satyam-store`.
2. Open your Pages project → **Settings → Bindings → Add → KV namespace**.
   - Variable name: `STORE`  (exactly this, capital letters)
   - KV namespace: `satyam-store`

### 4. Set your owner login
Pages project → **Settings → Variables and Secrets → Add**, and click **Encrypt** for each:

| Name | Value |
|---|---|
| `OWNER_ID` | the Login ID you want, e.g. `satyam` |
| `OWNER_PASSWORD` | your password (6+ characters) |
| `SESSION_SECRET` | any long random text, e.g. `k29dh38xPq71vbn40alsd` |

### 5. Redeploy
**Deployments → ⋯ on the latest → Retry deployment** (bindings and secrets only take effect after a redeploy).

Your site link looks like `https://satyam-site.pages.dev`. Share that with customers.

## Daily use (owner, from your phone)
1. Open the site → tap **Owner Login** → enter your ID and password.
2. Tap **Add Item** → **Choose from Gallery** (or **Take Photo**) → fill details → **Save**.
3. Customers see it the next time they open or refresh the page.
4. Tap **Logout** when done.

Change your ID or password any time: **Owner Control → Security → Change Login**.
(After you change it once, the new one is used and the secrets from step 4 are only a backup.)

## Notes
- Free plan limits are very generous for a shop catalogue (KV: 1,000 writes/day; each save is 1 write, each photo is 1 write).
- If you forget your password: change `OWNER_PASSWORD` in Cloudflare, AND delete the key `auth` in KV (Storage → KV → satyam-store → delete `auth`).
- Photos are shrunk on the phone to about 1000px before upload, so they load fast for customers.
